# stuffforemmett
this is a website based off a idea for a "gameshow" that my little brother emmett made.
It will have more things later,
Made using CHATGPT AND BRAIN POWER :)
